# buku model > 2023-08-26 9:29am
https://universe.roboflow.com/objek-dalam-ayunda/buku-model

Provided by a Roboflow user
License: CC BY 4.0

